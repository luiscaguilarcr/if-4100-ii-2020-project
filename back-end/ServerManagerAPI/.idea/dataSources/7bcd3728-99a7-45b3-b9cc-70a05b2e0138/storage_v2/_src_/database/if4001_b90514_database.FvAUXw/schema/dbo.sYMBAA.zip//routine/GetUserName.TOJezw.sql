CREATE FUNCTION dbo.GetUserName (@email varchar(50))
RETURNS NVARCHAR(50)
AS
BEGIN
    DECLARE @name NVARCHAR(50);
    SELECT @name = first_name
    FROM [User]
    WHERE [User].email = @email
    RETURN @name
END
go

