CREATE FUNCTION dbo.GetUser (@email varchar(50))
    RETURNS TABLE
        AS
        RETURN
            (
                SELECT *
                FROM [User]
                WHERE [User].email = @email
            )
go

